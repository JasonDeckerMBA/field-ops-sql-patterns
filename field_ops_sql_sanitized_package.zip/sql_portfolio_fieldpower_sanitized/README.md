# Field Operations Analytics – SQL Patterns (Sanitized)

This repo demonstrates advanced SQL patterns drawn from a field-ops analytics workload.
_All entities, names, and thresholds have been sanitized and simplified for public sharing._

**Highlights**
- CTE pipeline for readable transformations
- Summarizing multi-appointment jobs into work/drive windows
- Deriving **DriveMinutes** and **WorkMinutes** and hour equivalents
- Technician name **pivot** (ROW_NUMBER + conditional MAX)
- Contact aggregation with `STRING_AGG`
- Mapping invoice lines to the nearest job end using `OUTER APPLY`

Tested on **SQL Server 2019+**.

> Note: If your source timestamps are stored in UTC, see the `AT TIME ZONE` comments in the query for friendly display-time conversion.

## Quick start

1. Run `sql/schema.sql` to create minimal schemas and tables.
2. Run `sql/sample_data.sql` to seed a tiny dataset.
3. Run `sql/neutralized_query.sql` to produce the analytics result.

## Files

- `sql/schema.sql` – minimal DDL for demo tables
- `sql/sample_data.sql` – tiny seed dataset
- `sql/neutralized_query.sql` – the main analytics query

MIT License.