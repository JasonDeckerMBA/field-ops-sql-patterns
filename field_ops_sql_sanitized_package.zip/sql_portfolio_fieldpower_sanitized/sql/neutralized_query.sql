/*
  Field Ops Analytics – Sanitized Demo
  Patterns: CTE pipeline, tech pivot, STRING_AGG, OUTER APPLY, minute/hour derivations.
  SQL Server 2019+
*/

WITH JobBase AS (
    SELECT
        J.WoJobId,
        J.WorkOrderId,
        J.ApptPrefDate,
        J.CreatedDate,
        JD.WorkTypeId,
        JD.WorkTaskId,
        S.SLAStartTime,
        S.SLAEndTime,
        S.IsSLAMet,
        J.InvoiceNo
    FROM ops.jobs J
    LEFT JOIN ops.job_details JD ON JD.WoJobId = J.WoJobId
    LEFT JOIN ops.job_sla     S  ON S.WoJobId  = J.WoJobId
),
Appt AS (
    SELECT
        WO.WoNumber                 AS work_order_number,
        JB.WoJobId                  AS wo_job_id,
        A.TechId                    AS tech_id,
        A.ScheduleStartDateCtz,
        A.SubmittedDate,
        A.StartTimeCtz,
        A.ArrivalTimeCtz,
        A.ServiceStartTimeCtz,
        A.ServiceEndTimeCtz
    FROM JobBase JB
    JOIN ops.work_orders  WO ON WO.WorkOrderId = JB.WorkOrderId
    JOIN ops.appointments A  ON A.WoJobId      = JB.WoJobId
    WHERE A.AppointmentStatusId = 1
),
TechDistinct AS (
    SELECT
        A.work_order_number,
        A.tech_id,
        MIN(A.ServiceStartTimeCtz) AS first_service_start,
        COALESCE(U.DisplayName, CONCAT(U.FirstName, ' ', U.LastName)) AS TechName
    FROM Appt A
    LEFT JOIN ref.users U ON U.LoginId = A.tech_id
    GROUP BY A.work_order_number, A.tech_id, COALESCE(U.DisplayName, CONCAT(U.FirstName, ' ', U.LastName))
),
TechRanked AS (
    SELECT
        work_order_number,
        TechName,
        ROW_NUMBER() OVER (PARTITION BY work_order_number ORDER BY first_service_start, TechName) AS rn
    FROM TechDistinct
),
TechPivot AS (
    SELECT
        work_order_number,
        COUNT(*) AS TechCount,
        MAX(CASE WHEN rn = 1 THEN TechName END) AS Tech1,
        MAX(CASE WHEN rn = 2 THEN TechName END) AS Tech2,
        MAX(CASE WHEN rn = 3 THEN TechName END) AS Tech3,
        MAX(CASE WHEN rn = 4 THEN TechName END) AS Tech4,
        MAX(CASE WHEN rn = 5 THEN TechName END) AS Tech5
    FROM TechRanked
    GROUP BY work_order_number
),
ContactsAgg AS (
    SELECT
        A.work_order_number,
        STRING_AGG(DISTINCT U.Email, ', ')   WITHIN GROUP (ORDER BY U.Email)      AS ScheduledUserEmailList,
        STRING_AGG(DISTINCT U.FirstName, ', ') WITHIN GROUP (ORDER BY U.FirstName) AS SchedulerFirstNameList,
        STRING_AGG(DISTINCT U.LastName, ', ')  WITHIN GROUP (ORDER BY U.LastName)  AS SchedulerLastNameList,
        STRING_AGG(DISTINCT COALESCE(U.DisplayName, CONCAT(U.FirstName,' ',U.LastName)), ', ')
            WITHIN GROUP (ORDER BY COALESCE(U.DisplayName, CONCAT(U.FirstName,' ',U.LastName))) AS SchedulerNameList
    FROM Appt A
    LEFT JOIN ref.users U ON U.LoginId = A.tech_id
    GROUP BY A.work_order_number
),
WO_Timing AS (
    SELECT
        A.work_order_number,
        MIN(A.StartTimeCtz)         AS DriveStartTime,
        MAX(A.ArrivalTimeCtz)       AS DriveEndTime,
        MIN(A.ServiceStartTimeCtz)  AS WorkStartTime,
        MAX(A.ServiceEndTimeCtz)    AS WorkEndTime,
        MAX(A.SubmittedDate)        AS submitted_date,
        MAX(A.ScheduleStartDateCtz) AS schedule_start_date,
        SUM(DATEDIFF(MINUTE, A.ArrivalTimeCtz, A.ServiceEndTimeCtz)) AS WorkMinutes,  -- Arrival -> ServiceEnd
        SUM(DATEDIFF(MINUTE, A.StartTimeCtz,   A.ArrivalTimeCtz))    AS DriveMinutes, -- Start   -> Arrival
        SUM(DATEDIFF(MINUTE, A.ArrivalTimeCtz, A.ServiceEndTimeCtz))/60.0 AS WorkHours,
        SUM(DATEDIFF(MINUTE, A.StartTimeCtz,   A.ArrivalTimeCtz))/60.0    AS DriveHours
    FROM Appt A
    GROUP BY A.work_order_number
),
WO_Main AS (
    SELECT
        WO.WoNumber                                 AS work_order_number,
        MIN(JB.ApptPrefDate)                        AS CustPrefTime,
        MIN(JB.CreatedDate)                         AS created_date,
        MIN(JB.InvoiceNo)                           AS InvoiceNo,
        MIN(WO.TimeZoneName)                        AS TimeZoneName
    FROM JobBase JB
    JOIN ops.work_orders WO ON WO.WorkOrderId = JB.WorkOrderId
    GROUP BY WO.WoNumber
),
JobsForWO AS (
    SELECT
        WO.WoNumber AS work_order_number,
        JB.WoJobId,
        JB.WorkTypeId,
        WT.WorkTypeName,
        CASE 
            WHEN WT.WorkTypeName LIKE 'Service - Fees/Charges%' THEN 16
            WHEN WT.WorkTypeName LIKE 'PM - Fees/Charges%'      THEN 15
            WHEN WT.WorkTypeName LIKE 'Install%'                THEN 14
            WHEN WT.WorkTypeName LIKE 'Service%'                THEN 12
            WHEN WT.WorkTypeName LIKE 'Training%'               THEN 18
            ELSE 12
        END AS job_type_id,
        JM.JobWorkEndTime
    FROM JobBase JB
    JOIN ops.work_orders WO ON WO.WorkOrderId = JB.WorkOrderId
    LEFT JOIN ref.work_type WT ON WT.WorkTypeId = JB.WorkTypeId
    LEFT JOIN (
        SELECT WoJobId, MAX(ServiceEndTimeCtz) AS JobWorkEndTime
        FROM ops.appointments
        WHERE AppointmentStatusId = 1
        GROUP BY WoJobId
    ) JM ON JM.WoJobId = JB.WoJobId
)
SELECT DISTINCT
    F.work_order_number,
    F.CustPrefTime,
    F.created_date,
    -- Rolled-up times & minutes/hours
    T.schedule_start_date,
    T.submitted_date,
    T.DriveStartTime,
    T.DriveEndTime,
    T.WorkStartTime,
    T.WorkEndTime,
    T.DriveMinutes,
    T.WorkMinutes,
    T.DriveHours,
    T.WorkHours,
    -- Tech roster (pivot + lists)
    TP.TechCount, TP.Tech1, TP.Tech2, TP.Tech3, TP.Tech4, TP.Tech5,
    CA.SchedulerNameList, CA.SchedulerFirstNameList, CA.SchedulerLastNameList, CA.ScheduledUserEmailList,
    -- Example: map an invoice line to nearest job via APPLY
    IL.OrderLineKey,
    JPick.WoJobId  AS JobNearestToInvoice,
    JPick.job_type_id,
    JPick.WorkTypeName
FROM WO_Main F
LEFT JOIN WO_Timing     T  ON T.work_order_number = F.work_order_number
LEFT JOIN TechPivot     TP ON TP.work_order_number = F.work_order_number
LEFT JOIN ContactsAgg   CA ON CA.work_order_number = F.work_order_number
-- join a demo invoice line for APPLY mapping
LEFT JOIN ops.invoice_lines IL
  ON IL.WorkOrderId = (SELECT TOP 1 WorkOrderId FROM ops.work_orders WHERE WoNumber = F.work_order_number)
OUTER APPLY (
    SELECT TOP 1 J.*
    FROM JobsForWO J
    WHERE J.work_order_number = F.work_order_number
    ORDER BY ABS(DATEDIFF(MINUTE, J.JobWorkEndTime, IL.InvDate)), J.WoJobId
) JPick
ORDER BY F.work_order_number;