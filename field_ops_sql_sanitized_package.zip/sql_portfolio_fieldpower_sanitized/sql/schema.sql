-- Minimal schemas
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'ops') EXEC('CREATE SCHEMA ops');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'ref') EXEC('CREATE SCHEMA ref');

-- Work orders
IF OBJECT_ID('ops.work_orders') IS NOT NULL DROP TABLE ops.work_orders;
CREATE TABLE ops.work_orders (
    WorkOrderId       INT         NOT NULL PRIMARY KEY,
    WoNumber          NVARCHAR(20) NOT NULL UNIQUE,
    TimeZoneName      SYSNAME     NULL,  -- e.g., 'Eastern Standard Time'
    CreatedDate       DATETIME2   NOT NULL
);

-- Jobs
IF OBJECT_ID('ops.jobs') IS NOT NULL DROP TABLE ops.jobs;
CREATE TABLE ops.jobs (
    WoJobId        INT         NOT NULL PRIMARY KEY,
    WorkOrderId    INT         NOT NULL REFERENCES ops.work_orders(WorkOrderId),
    ApptPrefDate   DATETIME2   NULL,
    CreatedDate    DATETIME2   NOT NULL,
    InvoiceNo      INT         NULL
);

-- Job details (work type/task)
IF OBJECT_ID('ops.job_details') IS NOT NULL DROP TABLE ops.job_details;
CREATE TABLE ops.job_details (
    WoJobId      INT NOT NULL REFERENCES ops.jobs(WoJobId),
    WorkTypeId   INT NOT NULL,
    WorkTaskId   INT NULL
);

-- Job SLA
IF OBJECT_ID('ops.job_sla') IS NOT NULL DROP TABLE ops.job_sla;
CREATE TABLE ops.job_sla (
    WoJobId       INT NOT NULL REFERENCES ops.jobs(WoJobId),
    SLAStartTime  DATETIME2 NOT NULL,
    SLAEndTime    DATETIME2 NULL,
    IsSLAMet      BIT NULL
);

-- Appointments
IF OBJECT_ID('ops.appointments') IS NOT NULL DROP TABLE ops.appointments;
CREATE TABLE ops.appointments (
    WoAppointmentId        INT IDENTITY PRIMARY KEY,
    WoJobId                INT NOT NULL REFERENCES ops.jobs(WoJobId),
    TechId                 INT NOT NULL,
    AppointmentStatusId    INT NOT NULL, -- 1 = active/valid
    ScheduleStartDateCtz   DATETIME2 NULL,
    SubmittedDate          DATETIME2 NULL,
    StartTimeCtz           DATETIME2 NULL,
    ArrivalTimeCtz         DATETIME2 NULL,
    ServiceStartTimeCtz    DATETIME2 NULL,
    ServiceEndTimeCtz      DATETIME2 NULL
);

-- Users (techs, schedulers, etc)
IF OBJECT_ID('ref.users') IS NOT NULL DROP TABLE ref.users;
CREATE TABLE ref.users (
    LoginId     INT PRIMARY KEY,
    DisplayName NVARCHAR(200) NULL,
    FirstName   NVARCHAR(100) NULL,
    LastName    NVARCHAR(100) NULL,
    Email       NVARCHAR(200) NULL
);

-- Work type reference
IF OBJECT_ID('ref.work_type') IS NOT NULL DROP TABLE ref.work_type;
CREATE TABLE ref.work_type (
    WorkTypeId   INT PRIMARY KEY,
    WorkTypeName NVARCHAR(100) NOT NULL
);

-- Invoice lines (for OUTER APPLY mapping demo)
IF OBJECT_ID('ops.invoice_lines') IS NOT NULL DROP TABLE ops.invoice_lines;
CREATE TABLE ops.invoice_lines (
    WorkOrderId    INT NOT NULL REFERENCES ops.work_orders(WorkOrderId),
    InvDate        DATETIME2 NOT NULL,
    OrderLineKey   INT NOT NULL
);