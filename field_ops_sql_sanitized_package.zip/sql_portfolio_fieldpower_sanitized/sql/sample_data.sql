-- Seed data (tiny demo)

-- Work order
INSERT INTO ops.work_orders (WorkOrderId, WoNumber, TimeZoneName, CreatedDate)
VALUES (1, 'WO1001', 'Eastern Standard Time', '2025-07-01T08:00:00');

-- Job
INSERT INTO ops.jobs (WoJobId, WorkOrderId, ApptPrefDate, CreatedDate, InvoiceNo)
VALUES (100, 1, '2025-07-03T00:00:00', '2025-07-02T10:00:00', 555);

-- Job details
INSERT INTO ops.job_details (WoJobId, WorkTypeId, WorkTaskId)
VALUES (100, 10, 501);

-- Work type
INSERT INTO ref.work_type (WorkTypeId, WorkTypeName)
VALUES (10, 'Service - Break/Fix');

-- SLA
INSERT INTO ops.job_sla (WoJobId, SLAStartTime, SLAEndTime, IsSLAMet)
VALUES (100, '2025-07-05T09:00:00', '2025-07-05T17:00:00', 1);

-- Users (tech)
INSERT INTO ref.users (LoginId, DisplayName, FirstName, LastName, Email)
VALUES (200, 'Alex Tech', 'Alex', 'Tech', 'alex.tech@example.com');

-- Appointments for job 100 (two segments in the day)
INSERT INTO ops.appointments (WoJobId, TechId, AppointmentStatusId, ScheduleStartDateCtz, SubmittedDate,
                              StartTimeCtz, ArrivalTimeCtz, ServiceStartTimeCtz, ServiceEndTimeCtz)
VALUES
(100, 200, 1, '2025-07-05T07:00:00', '2025-07-05T06:30:00',
 '2025-07-05T07:30:00', '2025-07-05T07:45:00', '2025-07-05T07:50:00', '2025-07-05T09:10:00'),
(100, 200, 1, '2025-07-05T13:00:00', '2025-07-05T12:45:00',
 '2025-07-05T13:00:00', '2025-07-05T13:20:00', '2025-07-05T13:30:00', '2025-07-05T14:00:00');

-- Invoice line (for mapping to nearest job end)
INSERT INTO ops.invoice_lines (WorkOrderId, InvDate, OrderLineKey)
VALUES (1, '2025-07-06T10:00:00', 1);